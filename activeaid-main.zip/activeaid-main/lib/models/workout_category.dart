class WorkoutCategory {
  final int id;
  final String name;

  WorkoutCategory({
    required this.id,
    required this.name,
  });
}
