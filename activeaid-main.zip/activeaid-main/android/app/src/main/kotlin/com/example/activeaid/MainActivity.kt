package com.example.activeaid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
